def add(a: int, b: int):
    "add two numbers"
    return a + b